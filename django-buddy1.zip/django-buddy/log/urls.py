#!python
# log/urls.py
from django.conf.urls import url
from . import views

# We are adding a URL called /home
urlpatterns = [
    url(r'^$', views.home, name='home'),
    url(r'^$', views.home, name='create_list'),
    url(r'^create_list/add_list/$', views.add_list, name='add_list'),

]
