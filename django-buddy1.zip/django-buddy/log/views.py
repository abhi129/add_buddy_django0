#!python
#log/views.py
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

# Create your views here.
# this login required decorator is to not allow to any  
# view without authenticating
from log.forms import ListForm
from log.models import List


@login_required(login_url="login/")
def home(request):
	return render(request,"home.html")


def create_list(request):
	return render(request,"list_create.html")


def add_list(request):
	if request.method == 'POST':
		form = ListForm(request.POST)

		if form.is_valid():
			#assigned_by = form.cleaned_data['buddy_email']
			list_name = request.POST['list_name']
			assigned_to = request.POST['buddy_email']
			list  = List(list_name = list_name, assigned_to = assigned_to, assigned_by = 'test1@gmail.com' )
			list.save()
			return HttpResponseRedirect('/')