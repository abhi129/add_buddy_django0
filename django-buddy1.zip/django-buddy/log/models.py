import uuid

from django.db import models

# Create your models here.



class List(models.Model):
    list_name = models.CharField(max_length=30)
    assigned_to = models.EmailField(max_length=100)
    assigned_by = models.EmailField(max_length=100)

class Task(models.Model):
    list_id = models.IntegerField()
    task_desc = models.CharField(max_length=200, default="task")
    task_status = models.IntegerField(default=0)


